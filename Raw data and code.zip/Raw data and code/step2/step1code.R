#####################################
#数据与代码声�?#如果没有购买SCI狂人团队或者生信狂人团队的正版会员
#没有经过我们的同意，擅自使用我们整理好的数据与代码发文章
#如果被我们发现你的文章用了我们的数据与代码，我们将使用一切手段让你的文章撤稿

####关注微信公众号生信狂人团�?###遇到代码报错等不懂的问题可以添加微信scikuangren进行答疑
###作者邮箱：sxkrteam@shengxinkuangren.com


#install packages
#install.packages("devtools")
#devtools::install_github("MRCIEU/TwoSampleMR")

#install.packages("ggplot2")

#library
library(TwoSampleMR)
library(ggplot2)
library(foreach)

setwd("/Volumes/sxkrteam/MG412IMM731/imctxtdf")

#数据与代码声�?#如果没有购买SCI狂人团队或者生信狂人团队的正版会员
#没有经过我们的同意，擅自使用我们整理好的数据与代码发文章
#如果被我们发现你的文章用了我们的数据与代码，我们将使用一切手段让你的文章撤稿
####关注微信公众号生信狂人团�?###遇到代码报错等不懂的问题可以添加微信scikuangren进行答疑
###作者邮箱：sxkrteam@shengxinkuangren.com

i="id.1234 "

dxw=read.table("imc731id.txt",header = T,sep = "\t")
dxwid=as.vector(dxw$id)

#dxwid=dxwid[1:10]

result=data.frame()
foreach(j=dxwid, .errorhandling = "pass") %do%{
  expo_rt<- read_exposure_data(
    filename = paste0(i,".txt"),
    sep = "\t",
  snp_col = "SNP",
  beta_col = "beta.exposure",
  se_col = "se.exposure",
  effect_allele_col = " effect_allele.exposure ",
  other_allele_col = " other_allele.exposure ",
  eaf_col = " eaf.exposure ",
  pval_col = "pval.exposure",samplesize_col = " samplesize.exposure "
  )
    #数据与代码声�?    #如果没有购买SCI狂人团队或者生信狂人团队的正版会员
    #没有经过我们的同意，擅自使用我们整理好的数据与代码发文章
    #如果被我们发现你的文章用了我们的数据与代码，我们将使用一切手段让你的文章撤稿
    outc_rt <- read_outcome_data(
      snps = expo_rt$SNP,
      filename = paste0(j,".txt.gz"),
      sep = "\t",
      snp_col = "SNP",
      beta_col = "beta",
      se_col = "se",
      effect_allele_col = "A1",
      other_allele_col = "A2",
      eaf_col = "eaf",
      pval_col = "p",
      samplesize_col = "n"
    )
    
    
    harm_rt <- harmonise_data(
      exposure_dat =  expo_rt, 
      outcome_dat = outc_rt,action=2)
    harm_rt$R2 <- (2 * (harm_rt$beta.exposure^2) * harm_rt$eaf.exposure * (1 - harm_rt$eaf.exposure)) /
      (2 * (harm_rt$beta.exposure^2) * harm_rt$eaf.exposure * (1 - harm_rt$eaf.exposure) +
         2 * harm_rt$samplesize.exposure*harm_rt$eaf.exposure * (1 - harm_rt$eaf.exposure) * harm_rt$se.exposure^2)
    harm_rt$f <- harm_rt$R2 * (harm_rt$samplesize.exposure - 2) / (1 - harm_rt$R2)
    harm_rt$meanf<- mean( harm_rt$f)
    harm_rt<-harm_rt[harm_rt$f>10,]
mr_result<- mr(harm_rt)
result_or=generate_odds_ratios(mr_result)
if(result_or$pval[3]<0.05){
  result=rbind(result,cbind(gm=i,imm=j,pvalue=result_or$pval[3]))
  
}
  }

write.table(result,"firstselect.txt",sep = "\t",quote = F,row.names = F)





#####################################
#数据与代码声�?#如果没有购买SCI狂人团队或者生信狂人团队的正版会员
#没有经过我们的同意，擅自使用我们整理好的数据与代码发文章
#如果被我们发现你的文章用了我们的数据与代码，我们将使用一切手段让你的文章撤稿

####关注微信公众号生信狂人团�?###遇到代码报错等不懂的问题可以添加微信scikuangren进行答疑
###作者邮箱：sxkrteam@shengxinkuangren.com 



